"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = (event, context) => {
    return Promise.resolve({
        statusCode: 200,
        body: JSON.stringify({ message: "Hello TS!", event, context }, null, 2)
    });
};
